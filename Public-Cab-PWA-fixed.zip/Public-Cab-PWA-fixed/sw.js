// Public Cab PWA service worker — safe for GitHub Pages project subpaths.
const CACHE_NAME = 'public-cab-pwa-v2';
const APP_BASE = new URL('./', self.registration.scope);
const APP_SHELL = [
  new URL('./', APP_BASE).href,
  new URL('./index.html', APP_BASE).href,
  new URL('./manifest.webmanifest', APP_BASE).href,
  new URL('./icons/icon-192.png', APP_BASE).href,
  new URL('./icons/icon-512.png', APP_BASE).href
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith('public-cab-pwa-') && key !== CACHE_NAME).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || !url.pathname.startsWith(APP_BASE.pathname)) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(new URL('./index.html', APP_BASE).href, copy));
      }
      return response;
    }).catch(async () => {
      const cache = await caches.open(CACHE_NAME);
      return (await cache.match(new URL('./index.html', APP_BASE).href)) || cache.match(new URL('./', APP_BASE).href);
    }));
    return;
  }

  event.respondWith(fetch(request).then(response => {
    if (response && response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
    }
    return response;
  }).catch(async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    throw new Error('Resource unavailable offline');
  }));
});
